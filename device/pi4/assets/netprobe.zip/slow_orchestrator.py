"""
Copyright (c) 2024 Netmeldr. All rights reserved.

This file is part of Netprobe IOT device, which is proprietary software.
Unauthorized copying, modification, distribution, or use of this file,
via any medium, is strictly prohibited.
"""

import json
import threading
import time

import docker
import requests

from config.config import config
from containers.logger import DisplayLogger
from utils import is_wifi_connected


CONFIG_PATH = config.config_file_path
SERVICE_URL = 'http://localhost:8889/mqtt'

lcd_display_logger = DisplayLogger()


def load_config():
    with open(CONFIG_PATH, 'r') as f:
        return json.load(f)


def main():
    # Start Wi-Fi connectivity check in the background
    # Note:- creating a simple boolean for wifi_connected causing some issues reason unknown
    wifi_connected = [False]  # Use a mutable object to track status

    def check_wifi():
        if is_wifi_connected():
            wifi_connected[0] = True

    threading.Thread(target=check_wifi, daemon=True).start()

    # Display "No Internet Connection" if Wi-Fi is not connected
    time.sleep(2)  # Allow some time for initial checks
    if not wifi_connected[0]:
        lcd_display_logger.log("No Internet Connection")
        return

    # Proceed with the rest of the logic
    config_dict = load_config()
    lcd_display_logger.log('starting tests ...')

    containers = config_dict['slow_test_containers']
    for container_config in containers:
        image_name = container_config['image_name']
        environment_variables = []
        for env in container_config['env']:
            environment_variables.append(f"{env['name']}={env['value']}")

        # append page-load urls as comma separated string
        environment_variables.append(f'URLS={",".join(config_dict["pageload_urls"])}')
        environment_variables.append(f'ORG_ID={config_dict["organization_id"]}')
        test_result = run_docker(image_name, environment_variables)

        # post results over mqtt
        requests.post(SERVICE_URL, json=json.loads(test_result))

    lcd_display_logger.log('ran all tests successfully')


def run_docker(image_name, environment_variables):
    client = docker.from_env()
    result = client.containers.run(image=image_name, environment=environment_variables, network_mode='host').decode(
        'utf-8')
    return result


if __name__ == '__main__':
    main()
