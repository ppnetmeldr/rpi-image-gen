#!/usr/bin/env bash


# Check if the script is run as root
if [ "$EUID" -ne 0 ]
then
  echo "Please run this script as root."
  exit 1
fi


# Unzip the netprobe.zip file into /opt/netmeldr/netprobe
echo "updating files ..."
unzip netprobe.zip -d /opt/netmeldr/netprobe

echo "updating virtual environment for netprobe service ..."
cd /opt/netmeldr/netprobe
source /opt/netmeldr/netprobe/venv/bin/activate

echo "installing python required packages ..."
if [ -f /opt/netmeldr/netprobe/requirements.txt ]; then
    pip install -r /opt/netmeldr/netprobe/requirements.txt
else
    echo "requirements.txt not found in /opt/netmeldr/netprobe"
fi


echo "installing netprobe as a service ..."
cp /opt/netmeldr/netprobe/linux/netprobe.service /etc/systemd/system/netprobe.service
cp /opt/netmeldr/netprobe/linux/netprobe-mqtt.service /etc/systemd/system/netprobe-mqtt.service
cp /opt/netmeldr/netprobe/linux/netprobe-event.service /etc/systemd/system/netprobe-event.service

systemctl daemon-reload
systemctl enable netprobe.service netprobe-mqtt.service netprobe-event.service
systemctl start netprobe.service netprobe-mqtt.service netprobe-event.service
systemctl status netprobe.service netprobe-mqtt.service netprobe-event.service

echo "Script execution completed."
