"""
Copyright (c) 2024 Netmeldr. All rights reserved.

This file is part of Netprobe IOT device, which is proprietary software.
Unauthorized copying, modification, distribution, or use of this file,
via any medium, is strictly prohibited.
"""
import asyncio
import json
import os
import re
import statistics
import subprocess
import time

import requests
import speedtest
from icmplib import traceroute
from pyppeteer import launch

from logger import DisplayLogger

lcd_display_logger = DisplayLogger()

YOUTUBE_API_KEY = os.getenv("YOUTUBE_API_KEY")

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/143.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-IN,en;q=0.9",
}

def ping_host(host="8.8.8.8", count=5):
    """
    Ping a host and return statistics including jitter, latency and packet loss.
    """
    try:
        ping_cmd = ["ping", "-c", str(count), host]
        result = subprocess.run(ping_cmd, capture_output=True, text=True, timeout=10)

        ping_times = []
        packets_sent = count
        packets_received = 0

        for line in result.stdout.splitlines():
            if "time=" in line:
                packets_received += 1
                match = re.search(r"time=([0-9.]+)", line)
                if match:
                    ping_time = float(match.group(1))
                    ping_times.append(ping_time)

        if ping_times:
            min_ping = min(ping_times)
            max_ping = max(ping_times)
            avg_ping = sum(ping_times) / len(ping_times)
            jitter = statistics.stdev(ping_times) if len(ping_times) > 1 else 0
            packet_loss = ((packets_sent - packets_received) / packets_sent) * 100

            return {
                "packets_sent": packets_sent,
                "packets_received": packets_received,
                "packet_loss_percent": packet_loss,
                "min_latency_ms": min_ping,
                "max_latency_ms": max_ping,
                "avg_latency_ms": avg_ping,
                "jitter_ms": jitter
            }
        else:
            return {
                "packets_sent": packets_sent,
                "packets_received": 0,
                "packet_loss_percent": 100.0,
                "error": "No ping responses received"
            }

    except subprocess.TimeoutExpired:
        return {"error": "Ping command timed out"}
    except Exception as e:
        return {"error": str(e)}


async def get_page_load(url):
    browser = None
    try:
        exe_path = '/usr/bin/chromium'
        browser = await launch(
            headless=True,
            executablePath=exe_path,
            args=[
                '--no-sandbox',
                '--disable-gpu',
                '--disable-dev-shm-usage',
                '--disable-setuid-sandbox'
            ]
        )

        page = await browser.newPage()
        await page.goto(url, timeout=30000)

        perf_json = await page.evaluate(
            "() => JSON.stringify(performance.getEntriesByType('navigation'))"
        )
        result = json.loads(perf_json)

        redirect = result[0]['redirectEnd'] - result[0]['redirectStart']
        dnsTime = result[0]['domainLookupEnd'] - result[0]['domainLookupStart']
        connectTime = result[0]['connectEnd'] - result[0]['connectStart']
        requestTime = result[0]['responseStart'] - result[0]['requestStart']
        sslHandshake = result[0]['secureConnectionStart'] - result[0]['connectStart']
        result = {
            'redirect': redirect,
            'dnsTime': dnsTime,
            'connectTime': connectTime,
            'requestTime': requestTime,
            'sslHandshake': sslHandshake,
        }
        return result

    except Exception as e:
        result = {
            'redirect': 0,
            'dnsTime': 0,
            'connectTime': 0,
            'requestTime': 0,
            'sslHandshake': 0,
            'err': str(e)
        }
        return result

    finally:
        if browser:
            try:
                await browser.close()
            except:
                pass


async def run_page_load_tests():
    url_str = os.getenv('URLS')
    urls = url_str.split(',')
    data = {
        'urls': urls
    }
    for i, url in enumerate(urls):
        lcd_display_logger.log(f'[progress] {i}/{len(urls)}')
        old_url = url
        url, reason = validate_url(url)

        if not url:
            data[old_url] = {
                'redirect': 0,
                'dnsTime': 0,
                'connectTime': 0,
                'requestTime': 0,
                'sslHandshake': 0,
                'err': reason
            }
        else:
            temp = await get_page_load(url)
            temp['err'] = reason
            data[url] = temp

    result = get_result_dict()
    result['type'] = 'pageloadmetrics'
    result['data'] = data
    return result


def validate_url(url):
    session = requests.Session()
    session.headers.update(HEADERS)
    try:
        res = session.get(url, allow_redirects=False, timeout=10)
    except Exception:
        return url, "invalid url"

    if 200 <= res.status_code < 300:
        return url, res.reason

    if res.is_redirect:
        return res.headers.get("Location"), res.reason

    if res.status_code == 403:
        time.sleep(0.7) 
        try:
            res = session.get(url, allow_redirects=False, timeout=10)
        except Exception:
            return url, "invalid url"

        if 200 <= res.status_code < 300:
            return url, res.reason

        if res.is_redirect:
            return res.headers.get("Location"), res.reason

    return url, res.reason


def get_result_dict():
    result = dict()
    result['organization_id'] = os.getenv('ORG_ID')
    result['site_name'] = os.getenv('DEVICE_ID')
    result['created_at'] = time.time()
    result['updated_at'] = result['created_at']
    return result


def get_ping_metrics():
    lcd_display_logger.log('[test] download...')
    test = speedtest.Speedtest(secure=True)
    download_result = test.download() / (1024 * 1024)

    lcd_display_logger.log('[test] upload...')
    upload_result = test.upload() / (1024 * 1024)
    ping_result = test.results.ping

    lcd_display_logger.log('[test] ping...')
    ping_stats = ping_host("google.com", 5)  # pinging 5 times

    if "error" in ping_stats:
        lcd_display_logger.log(f'[error] Ping failed: {ping_stats["error"]}')
        data = {
            'downloadspeed': download_result,
            'uploadspeed': upload_result,
            'ping': ping_result,
            'jitter': 0,
            'packetloss': 100,
            'latency': 0
        }
    else:
        data = {
            'downloadspeed': download_result,
            'uploadspeed': upload_result,
            'ping': ping_result,
            'jitter': ping_stats['jitter_ms'],
            'packetloss': ping_stats['packet_loss_percent'],
            'latency': ping_stats['avg_latency_ms']
        }

    result = get_result_dict()
    result['type'] = 'pingmetrics'
    result['data'] = data
    return result


def record_traceroute():
    routes = traceroute('www.google.com', count=3)

    lines = []
    for i, route in enumerate(routes):
        temp = {
            'seq': i,
            'ip': route.address,
            'jitter': route.jitter,
            'rtt': route.avg_rtt,
            'min_rtt': route.min_rtt,
            'max_rtt': route.max_rtt,
            'anomaly': False
        }
        lines.append(temp)

    result = get_result_dict()
    result['data'] = {'hops': lines}
    result['type'] = 'tracecroutemetrics'
    return result


def get_iwdata():
    data = requests.get('http://localhost:8888/iwdata').json()
    result = get_result_dict()
    result['data'] = data
    result['type'] = 'iwmetrics'
    return result


def get_iw_events():
    data = requests.get('http://localhost:8888/iwevent').json()
    result = get_result_dict()
    result['data'] = data
    result['type'] = 'iwevents'
    return result


async def main():
    result = list()
    lcd_display_logger.log('[loaded] page metrics')
    page_load_metrics = await run_page_load_tests()
    result.append(page_load_metrics)

    lcd_display_logger.log('[test] ping metrics')
    result.append(get_ping_metrics())

    lcd_display_logger.log('[test] traceroute')
    result.append(record_traceroute())

    lcd_display_logger.log('[test] gather signal metrics')
    result.append(get_iwdata())

    lcd_display_logger.log('[info] collecting events')
    result.append(get_iw_events())

    print(json.dumps(result))


asyncio.new_event_loop().run_until_complete(main())
