"""
Copyright (c) 2024 Netmeldr. All rights reserved.

This file is part of Netprobe IOT device, which is proprietary software.
Unauthorized copying, modification, distribution, or use of this file,
via any medium, is strictly prohibited.
"""
import requests


class DisplayLogger:
    def __init__(self, url='http://127.0.0.1:8888/logs'):
        self.url = url

    def log(self, message):
        try:
            requests.post(self.url, json={'logs': message})
        except:
            print(message)
