"""
Copyright (c) 2024 Netmeldr. All rights reserved.

This file is part of Netprobe IOT device, which is proprietary software.
Unauthorized copying, modification, distribution, or use of this file,
via any medium, is strictly prohibited.
"""
import asyncio
import json
import os
import time
import requests
import cv2
import yt_dlp
from googleapiclient.discovery import build

from logger import DisplayLogger

lcd_display_logger = DisplayLogger()





def measure_video_parameters(video_url, duration):
    cap = cv2.VideoCapture(video_url)

    if not cap.isOpened():
        print("Error: Could not open video.")
        return None

    fps = cap.get(cv2.CAP_PROP_FPS)

    # Initialize variables
    start_time = time.time()
    frame_count = 0
    processing_times = []
    frame_delays = []
    buffer_time = 0
    waiting_time = 0  # Time spent waiting/buffering

    # Use duration to determine when to stop
    end_time_limit = start_time + duration

    while cap.isOpened() and time.time() < end_time_limit:
        frame_start = time.time()

        ret, frame = cap.read()
        if not ret:
            # If we reach the end of the video before duration, loop back
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            continue

        # Calculate frame processing time
        processing_time = time.time() - frame_start
        processing_times.append(processing_time)

        # Calculate ideal time between frames based on video FPS
        ideal_frame_time = 1.0 / fps if fps > 0 else 0.033  # Default to 30fps

        # If processing is faster than ideal frame rate, this is buffer time
        if processing_time < ideal_frame_time:
            frame_buffer = ideal_frame_time - processing_time
            buffer_time += frame_buffer

            # Simulate waiting for the next frame timing
            time.sleep(frame_buffer)
        else:
            # If processing takes longer than ideal, this is waiting time
            waiting_time += (processing_time - ideal_frame_time)

        # Track actual frame delay
        frame_delays.append(time.time() - frame_start)
        frame_count += 1

    elapsed_time = time.time() - start_time

    # lag ratio = (time the user had to wait / total viewing time)
    lag_ratio = (waiting_time / elapsed_time)

    actual_fps = frame_count / elapsed_time if elapsed_time > 0 else 0

    # Release the capture
    cap.release()

    return {
        'fps': actual_fps,
        'buffer_time': buffer_time,
        'lag_ratio': lag_ratio,
        'waiting_time': waiting_time
    }


def get_result_dict():
    result = dict()
    result['organization_id'] = os.getenv('ORG_ID')
    result['site_name'] = os.getenv('DEVICE_ID')
    result['created_at'] = time.time()
    result['updated_at'] = result['created_at']
    return result


async def main():
    result = list()
    lcd_display_logger.log('[test] running stream metrics')
    stream_metrics = await get_stream_metrics()
    result.append(stream_metrics)

    print(json.dumps(result))


async def get_stream_metrics():
    lcd_display_logger.log('[test] fetching random video...')
    backend_api_url = "https://api.netprobe.co"
    backend_api_key = os.getenv("BACKEND_API_KEY")
    youtube_video_api_endpoint = f'{backend_api_url}/test-video-url'    
    headers = {
        'api-key': backend_api_key
    }    
    
    youtube_url = None
    try:
        youtube_api_response = requests.get(
            youtube_video_api_endpoint, 
            headers=headers,  
            timeout=10
        )
        
        if youtube_api_response.status_code == 200:
            response_data = youtube_api_response.json()
            youtube_url = response_data['video_url']
        else:
            lcd_display_logger.log(f"[err] : Unable to find youtube video")
    except requests.exceptions.RequestException as e:
        lcd_display_logger.log(f'[err] Request failed: {str(e)}')

    lcd_display_logger.log('[debug] get_stream_metrics proceeding with video analysis')
    
    try:
        video_info = get_video_info(youtube_url)
        lcd_display_logger.log(f'[test] analyzing video')
        res = measure_video_parameters(video_info['video_url'], video_info['duration'])

        data = {
            'bitrate': video_info["bitrate"],
            'fps': res['fps'],
            'buffer_time': res['buffer_time'],
            'lag_ratio': res['lag_ratio'],
            'length': video_info["duration"],
            'waiting_time': res['waiting_time']
        }

        result = get_result_dict()
        result['type'] = 'streamevents'
        result['data'] = data
        lcd_display_logger.log('[success] Stream metrics collected successfully')
        return result
    except Exception as e:
        lcd_display_logger.log(f'[err] Error processing video metrics: {type(e).__name__}: {str(e)}')
        return None

def get_video_info(youtube_url):
    """Extract video details (bit-rate, FPS, duration, video URL)."""
    ydl_opts = get_ydl_opts()
    fmt = get_best_quality_format(ydl_opts, youtube_url)
    ydl_opts['format'] = fmt

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(youtube_url, download=False)

    bit_rate = info.get('tbr', 0)
    bit_rate = max(bit_rate, info.get('vbr', 0))
    bit_rate = max(bit_rate, info.get('abr', 0))

    return {
        "title": info.get("title", "NA"),
        "duration": min(info.get("duration", 200), 180),  # Run for max 3 minutes
        "bitrate": bit_rate,  # Audio and Video bit_rate (kbps)
        "fps": info.get("fps", "N/A"),
        "video_url": info.get("url", ""),
    }


def get_ydl_opts():
    ydl_opts = {
        'nocheckcertificate': True,  # Bypass SSL verification
        'quiet': True,  # Suppress yt_dlp output
        'no_warnings': True,  # Suppress warnings
        'http_headers': {
            'Connection': 'close',  # This tells the HTTP client not to reuse connections
        }
    }
    return ydl_opts


def get_best_quality_format(ydl_opts, youtube_url):
    format_id = 'best'
    quality = -1
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        available_formats = ydl.extract_info(youtube_url, download=False, process=False)
        for fmt in available_formats.get('formats', []):
            if fmt.get('quality', None) and fmt.get('quality') > quality:
                quality = fmt.get('quality')
                format_id = fmt.get('format_id')
    return format_id


asyncio.new_event_loop().run_until_complete(main())
