import logging
import os
from logging.handlers import RotatingFileHandler
from config import config

LOG_FILE_DIR = config.log_path
LOG_FILE_SIZE = 5 * 1024 * 1024  # 5 MB
BACKUP_COUNT = 3  # Keep up to 3 backup files


def get_file_logger(logger_name, log_file_name):
    """
    Configure and return a logger for a specific file.
    :param logger_name: Unique name for the logger.
    :param log_file_name: log file name.
    :return: Configured logger instance.
    """
    # Ensuring log file exists
    final_log_file_path = os.path.join(LOG_FILE_DIR, log_file_name)
    os.makedirs(os.path.dirname(final_log_file_path), exist_ok=True)
    print(f'Log file path: {final_log_file_path}')

    # Get or create the logger
    logger = logging.getLogger(logger_name)

    # If the logger is already configured, return it
    if logger.hasHandlers():
        return logger

    # Set logging level
    logger.setLevel(logging.INFO)

    # Configure RotatingFileHandler
    handler = RotatingFileHandler(
        final_log_file_path,
        maxBytes=LOG_FILE_SIZE,
        backupCount=BACKUP_COUNT
    )
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # Add handler to the logger
    logger.addHandler(handler)

    return logger
