#!/usr/bin/env bash


# Check if the script is run as root
if [ "$EUID" -ne 0 ]
then
  echo "Please run this script as root."
  exit 1
fi

echo "installing docker ..."
# Add Docker's official GPG key:
sudo apt-get update
sudo apt-get install ca-certificates curl gnupg
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

# Add the repository to Apt sources:
echo \
  "deb [arch="$(dpkg --print-architecture)" signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian \
  "$(. /etc/os-release && echo "$VERSION_CODENAME")" stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

echo "installing python and pip ..."
apt install python3 python3-pip

# Create the directory /opt/netmeldr/netprobe
mkdir -p /opt/netmeldr/netprobe

# Unzip the netprobe.zip file into /opt/netmeldr/netprobe
unzip netprobe.zip -d /opt/netmeldr/netprobe

echo "installing virtualenv ..."
pip3 install virtualenv --break-system-packages

echo "creating a virtual environment for netprobe service ..."
cd /opt/netmeldr/netprobe
virtualenv /opt/netmeldr/netprobe/venv
source /opt/netmeldr/netprobe/venv/bin/activate

echo "installing python required packages ..."
if [ -f /opt/netmeldr/netprobe/requirements.txt ]; then
    pip install -r /opt/netmeldr/netprobe/requirements.txt
else
    echo "requirements.txt not found in /opt/netmeldr/netprobe"
fi


echo "installing netprobe as a service ..."
SERVICE_DIR="/opt/netmeldr/netprobe/linux"
if [ ! -f "$SERVICE_DIR/netprobe.service" ] || [ ! -f "$SERVICE_DIR/netprobe-mqtt.service" ]; then
  echo "Error: Service files not found in $SERVICE_DIR"
  exit 1
fi

cp "$SERVICE_DIR/netprobe.service" /etc/systemd/system/netprobe.service
cp "$SERVICE_DIR/netprobe-mqtt.service" /etc/systemd/system/netprobe-mqtt.service
cp "$SERVICE_DIR/netprobe-event.service" /etc/systemd/system/netprobe-event.service


systemctl daemon-reload
systemctl enable netprobe.service netprobe-mqtt.service netprobe-event.service
systemctl start netprobe.service netprobe-mqtt.service netprobe-event.service


systemctl status netprobe.service
systemctl status netprobe-mqtt.service
systemctl status netprobe-event.service

echo "Script execution completed."







