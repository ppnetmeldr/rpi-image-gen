import json
import requests
from sandbox_executor import SandboxCodeExecutor

MQTT_SERVICE_URL = 'http://localhost:8889/mqtt'

executor = SandboxCodeExecutor(packages=['requests'])
try:
    test_results = executor.execute_tests("/opt/netmeldr/netprobe/custom_tests")

    if test_results is None:
        print("No valid test results found.")
    else:
        print(json.dumps(test_results, indent=2))
    requests.post(MQTT_SERVICE_URL, json=test_results)    
finally:
    executor.close()
