def main():
    x = 'ab'
    y = 'cd'    
    z = x+y
    return(z)

