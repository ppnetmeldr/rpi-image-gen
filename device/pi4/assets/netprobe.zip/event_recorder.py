"""
Copyright (c) 2024 Netmeldr. All rights reserved.

This file is part of Netprobe IOT device, which is proprietary software.
Unauthorized copying, modification, distribution, or use of this file,
via any medium, is strictly prohibited.
"""

import logging
import re
import subprocess
import time
import requests
from enum import Enum

from containers.global_logger import get_file_logger

LOG_FILE = "wifi_events.log"
URL = "http://localhost:8888/iwevent"


logger = get_file_logger("WiFiEvents", LOG_FILE)



class Event(Enum):
    CONNECTED = 1
    DISCONNECTED = 2


def parse_event_line(line):
    """Parse a line of iw event output to detect connection/disconnection."""
    if "connected to" in line:
        match = re.search(r"\[(.*)\] connected to", line)
        return Event.CONNECTED, match.group(1) if match else "unknown"
    elif "disconnected" in line:
        match = re.search(r"\[(.*)\] disconnected", line)
        return Event.DISCONNECTED, match.group(1) if match else "unknown"
    return None, None


def send_event(event_type):
    payload = dict()
    payload['time'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
    if event_type == Event.CONNECTED:
        payload['connected'] = True
        payload['disconnected'] = False
    else:
        payload['connected'] = False
        payload['disconnected'] = True

    try:
        requests.post(URL, json=payload)
    except:
        # TODO: retry??
        pass


def monitor_iw():
    try:
        process = subprocess.Popen(["iw", "event"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        logger.info("WiFi event monitoring started")
        for line in process.stdout:
            event_type, interface = parse_event_line(line.strip())
            if event_type:
                send_event(event_type)
                logging.info(f"Detected {event_type} event on {interface}.")
                logging.info(line)
    except KeyboardInterrupt:
        logging.debug("Monitoring stopped by user.")
    except FileNotFoundError:
        logging.debug("Error: 'iw' command not found. Please ensure wireless tools are installed.")
    except Exception as e:
        logging.debug(f"An error occurred: {e}")
        raise


if __name__ == '__main__':
    monitor_iw()
