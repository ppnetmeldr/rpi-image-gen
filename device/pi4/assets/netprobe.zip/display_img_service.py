"""
Copyright (c) 2025 Netmeldr. All rights reserved.

This file is part of Netprobe IOT device, which is proprietary software.
Unauthorized copying, modification, distribution, or use of this file,
via any medium, is strictly prohibited.
"""
import os

from PIL import Image, ImageDraw, ImageFont


class DisplayImageService:
    FONT_PATH_ENV = 'FONT_PATH'
    FONT_NAME = 'DejaVuSansCondensed.ttf'
    SCREEN_HEIGHT = 320
    SCREEN_WIDTH = 240
    ROTATION = 180
    SCREEN_BACKGROUND_COLOR = '#2C2C2C'
    MARGIN = 8

    def __init__(self):
        self.width = DisplayImageService.SCREEN_WIDTH
        self.height = DisplayImageService.SCREEN_HEIGHT
        self.margin = DisplayImageService.MARGIN

        self.bg_color = DisplayImageService.SCREEN_BACKGROUND_COLOR
        self.font_base_path = os.getenv(DisplayImageService.FONT_PATH_ENV, f'{os.getcwd()}/fonts')
        self.font_path = os.path.join(self.font_base_path, DisplayImageService.FONT_NAME)

        self.image = Image.new('RGB', (self.width, self.height), color=self.bg_color)
        self.draw = ImageDraw.Draw(self.image)

        self.debug = os.getenv('DEBUG', None)

    def get_image(self, rotation=ROTATION):
        if rotation == 0:
            return self.image

        return self.image.rotate(rotation)

    def draw_wifi(self, ssid):
        # clear area
        self._clear_area((0, 9), (160, 23), fill='red')
        if not ssid:
            return
        self._draw_wifi_symbol((6, 11), (20, 20))

        position = (self.margin + 25, self.margin)
        self._write_on_screen(ssid, position, font=12)

    def draw_battery(self, percentage):
        self._clear_area((165, 9), (240, 23), fill='green')

        charging = False
        if percentage > 102:
            charging = True
            percentage = 100

        percentage = min(100, percentage) # should not be more than 100
        percentage = max(0, percentage) # cannot be -ve
        self._draw_battery(percentage)
        if charging:
            self._write_on_screen("CHG⚡︎", (168, self.margin), font=12)

    def draw_device_name(self, name):
        text_width = min(240, len(name) * 7)
        self._clear_area((0, 23), (240, 42), fill='blue')
        self._write_on_screen(name, (120 - text_width // 2, 26))

    def draw_link_quality(self, quality):
        self._clear_area((0, 42), (120, 120), fill='red')
        self._draw_gauge(64, 105, 50, quality)

    def draw_signal_strength(self, strength):
        self._clear_area((121, 42), (240, 120), fill='green')
        if not strength:
            return
        self._write_on_screen(f'{strength} dB', (140, 80), font=30)

    def draw_logs(self, logs):
        self._clear_area((0, 120), (240, 260), fill='blue')
        for i, log in enumerate(logs):
            self._write_on_screen(log, (self.margin, 130 + i * 15))

    def draw_system_message(self, msg):
        self._clear_area((0, 260), (240, 300), fill='white')
        if not msg:
            return
        self._write_on_screen(msg, (self.margin, 262), color='red', font=20)

    def draw_ip_address(self, ip_address):
        self._clear_area((0, 300), (130, 320), fill="red")
        if ip_address:
            self._write_on_screen(ip_address, (self.margin, 302))
        else:
            self._write_on_screen("unassigned", (self.margin, 302))

    def draw_cpu_temperature(self, temperature):
        self._clear_area((132, 300), (240, 320), fill='green')
        self._write_on_screen(f'T: {temperature} C', (180, 302))

    def _draw_gauge(self, center_x, center_y, radius, value, min_value=0, max_value=100, gauge_color="#3492eb",
                    arc_width=15, font_size=34):
        draw = self.draw
        angle = (value / 2 - min_value) / (max_value - min_value) * 360
        start_angle = 180
        end_angle = start_angle + angle
        draw.arc((center_x - radius, center_y - radius, center_x + radius, center_y + radius), start=start_angle,
                 end=end_angle, fill=gauge_color, width=arc_width)
        draw.arc((center_x - radius, center_y - radius, center_x + radius, center_y + radius), start=start_angle,
                 end=360, fill='white', width=2)
        font = self._get_font(font_size)
        text_width = 19 if value < 100 else 4 * 7
        draw.text((center_x - text_width, center_y - 25), str(value), font=font, fill="white")

    def _draw_wifi_symbol(self, position, size, line_color=(255, 255, 255)):
        draw = self.draw
        x, y = position
        width, height = size
        arc_height_step = height // 5
        arc_width_step = width // 5
        for i in range(3):
            bbox = [x + arc_width_step * i, y + arc_height_step * i,
                    x + width - arc_width_step * i, y + height - arc_height_step * i]
            draw.arc(bbox, start=210, end=330, fill=line_color, width=2)

    def _write_on_screen(self, text: str, position, color='white', font=14):
        font = self._get_font(font)
        self.draw.text(position, text, fill=color, font=font)

    def _get_font(self, size):
        try:
            font = ImageFont.truetype(self.font_path, size)
        except IOError:
            font = ImageFont.load_default()
        return font

    def _clear_area(self, top_left, bottom_right, fill=None):
        if not self.debug:
            fill = self.bg_color  # comment this and uncomment the line below for dev
        fill = self.bg_color if not fill else fill
        self.draw.rectangle([top_left, bottom_right], fill=fill)

    def _draw_battery(self, battery_level, size=(30, 15), outline_color=(255, 255, 255), fill_color=(0, 255, 0)):
        level = max(0, battery_level)
        level = min(100, level)
        draw = self.draw
        width, height = size
        border = 2
        inner_width = width - 2 * border
        cap_width = int(width * 0.05)
        margin = self.margin
        x_offset = self.width - width - margin
        y_offset = margin

        draw.rectangle(
            [x_offset + border, y_offset + border,
             x_offset + width - border - cap_width, y_offset + height - border],
            outline=outline_color, width=1)

        draw.rectangle([x_offset + width - border - cap_width, y_offset + height // 3,
                        x_offset + width - border + 2, y_offset + height * 2 // 3],
                       outline=outline_color, fill=outline_color)

        fill_width = int((inner_width - cap_width) * level / 100)

        draw.rectangle([x_offset + border + 2, y_offset + border + 2,
                        x_offset + border + fill_width, y_offset + height - border - 2],
                       fill=fill_color)

    def draw_progress(self, progress):
        pass
