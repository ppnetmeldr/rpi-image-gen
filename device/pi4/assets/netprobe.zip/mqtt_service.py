"""
Copyright (c) 2024 Netmeldr. All rights reserved.

This file is part of Netprobe IOT device, which is proprietary software.
Unauthorized copying, modification, distribution, or use of this file,
via any medium, is strictly prohibited.
"""

import uvicorn

from fastapi import FastAPI
from typing import Dict, List
from awsmqtt import MQTT

app = FastAPI()
broker = MQTT()


@app.post("/mqtt")
async def send_message(payload: List[Dict]):
    broker.publish(payload=payload)
    return {"status": "OK"}


@app.get("/status")
async def status():
    return broker.is_connected()


if __name__ == '__main__':
    uvicorn.run(app, host='0.0.0.0', port=8889, workers=1)
