import os
import json
import time
from ai_code_sandbox import AICodeSandbox
from config.config import config

CONFIG_PATH = config.config_file_path


def load_config():
    with open(CONFIG_PATH, 'r') as f:
        return json.load(f)


class SandboxCodeExecutor:
    def __init__(self, packages=None):
        self.sandbox = AICodeSandbox(packages=packages, network_mode='bridge',
                                     custom_image='registry.digitalocean.com/netmeldr/customrunner:1')

    def run(self, code: str):
        try:
            result = self.sandbox.run_code(code)
            return json.loads(result) if result else None
        except Exception as e:
            return {"code": 1, "error": str(e)}

    def close(self):
        self.sandbox.close()

    @classmethod
    def get_result_dict(cls):
        result = dict()
        config_dict = load_config()
        result['organization_id'] = config_dict['organization_id']
        result['site_name'] = config_dict['site_name']
        result['created_at'] = time.time()
        result['updated_at'] = result['created_at']
        return result

    def execute_test(self, test_path):
        main_file = os.path.join(test_path, "main.py")
        metadata_file = os.path.join(test_path, "metadata.json")

        if os.path.exists(main_file) and os.path.exists(metadata_file):
            with open(main_file, "r") as file:
                code = file.read()

            # Properly wrapping the code

            wrapped_code = (
                    "import json\n"
                    + code
                    + "\n\n"
                      "if __name__ == '__main__':\n"
                      "    result = {}\n"
                      "    try:\n"
                      "        value = main()\n"
                      "        result['code'] = 0\n"
                      "        result['value'] = value\n"
                      "    except Exception as e:\n"
                      "        result['code'] = 1\n"
                      "        result['error'] = str(e)\n"
                      "    print(json.dumps(result))"
            )

            execution_result = self.run(wrapped_code)

            # Read metadata file
            with open(metadata_file, "r") as meta_file:
                metadata = json.load(meta_file)

            if execution_result:
                metadata.update(execution_result)

            return metadata
        return None

    def execute_tests(self, test_folder):
        results = []
        for test in os.listdir(test_folder):
            test_path = os.path.join(test_folder, test)
            if os.path.isdir(test_path):
                data = self.execute_test(test_path)
                result = SandboxCodeExecutor.get_result_dict()
                result['type'] = data['id']
                result['data'] = {'value': data.get('value', None),
                                  'code': data.get('code', None),
                                  'error': data.get('error', None)}
                if result:
                    results.append(result)
        return results
