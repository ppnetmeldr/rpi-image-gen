"""
Copyright (c) 2024 Netmeldr. All rights reserved.

This file is part of Netprobe IOT device, which is proprietary software.
Unauthorized copying, modification, distribution, or use of this file,
via any medium, is strictly prohibited.
"""
import copy
import json
import os.path
import threading
import shutil
from concurrent.futures import Future


import nmcli
from awscrt import mqtt5, io
from awsiot import iotjobs, mqtt5_client_builder

from config.config import config
from containers.global_logger import get_file_logger
from containers.logger import DisplayLogger

logger = get_file_logger("MQTTService", "mqtt-service.log")
io.init_logging(io.LogLevel.Info, os.path.join(config.log_file_path, "aws-sdk.log"))


class LockedData:
    def __init__(self):
        self.lock = threading.Lock()
        self.disconnect_called = False
        self.is_working_on_job = False
        self.is_next_job_waiting = False
        self.got_job_response = False


locked_data = LockedData()


class MQTT:
    available_jobs = []
    future_connection_success = Future()

    def __init__(self):
        self.mqtt5_client = mqtt5_client_builder.mtls_from_path(
            endpoint=config.endpoint,
            port=config.mqtt_port,
            cert_filepath=config.cert_filepath,
            pri_key_filepath=config.pri_key_filepath,
            ca_filepath=config.ca_filepath,
            http_proxy_options=None,
            clean_session=False,
            keep_alive_interval_sec=35,
            on_lifecycle_stopped=MQTT.on_lifecycle_stopped,
            on_lifecycle_connection_success=MQTT.on_lifecycle_connection_success,
            on_lifecycle_connection_failure=MQTT.on_lifecycle_connection_failure,
            client_id=config.client_id)

        self.connected = False

        self.lcd_display_logger = DisplayLogger()
        logger.info("Connecting to AWS IoT Core...")
        self.mqtt5_client.start()
        logger.info(f"Connected to {config.endpoint}")

        self.jobs_client = iotjobs.IotJobsClient(self.mqtt5_client)

        MQTT.future_connection_success.result()
        logger.info("Connected!")
        self.connected = True

        self.subscribe_to_jobs()

    def is_connected(self):
        return self.connected

    def subscribe_to_jobs(self):
        get_jobs_request = iotjobs.GetPendingJobExecutionsRequest(thing_name=config.client_id)
        jobs_request_future_accepted, _ = self.jobs_client.subscribe_to_get_pending_job_executions_accepted(
            request=get_jobs_request,
            qos=mqtt5.QoS.AT_LEAST_ONCE,
            callback=MQTT.on_get_pending_job_executions_accepted
        )
        # Wait for the subscription to succeed
        jobs_request_future_accepted.result()

        jobs_request_future_rejected, _ = self.jobs_client.subscribe_to_get_pending_job_executions_rejected(
            request=get_jobs_request,
            qos=mqtt5.QoS.AT_LEAST_ONCE,
            callback=MQTT.on_get_pending_job_executions_rejected
        )
        # Wait for the subscription to succeed
        jobs_request_future_rejected.result()

        # Get a list of all the jobs
        get_jobs_request_future = self.jobs_client.publish_get_pending_job_executions(
            request=get_jobs_request,
            qos=mqtt5.QoS.AT_LEAST_ONCE
        )
        # Wait for the publish to succeed
        get_jobs_request_future.result()

        self.subscribe_to_jobs_topics()

    def subscribe_to_jobs_topics(self):
        logger.info("Subscribing to Next changed events...")
        changed_subscription_request = iotjobs.NextJobExecutionChangedSubscriptionRequest(
            thing_name=config.client_id)

        subscribed_future, _ = self.jobs_client.subscribe_to_next_job_execution_changed_events(
            request=changed_subscription_request,
            qos=mqtt5.QoS.AT_LEAST_ONCE,
            callback=self.on_next_job_execution_changed)
        subscribed_future.result()

        logger.info("Subscribing to Start responses...")
        start_subscription_request = iotjobs.StartNextPendingJobExecutionSubscriptionRequest(
            thing_name=config.client_id)
        subscribed_accepted_future, _ = self.jobs_client.subscribe_to_start_next_pending_job_execution_accepted(
            request=start_subscription_request,
            qos=mqtt5.QoS.AT_LEAST_ONCE,
            callback=self.on_start_next_pending_job_execution_accepted)

        subscribed_rejected_future, _ = self.jobs_client.subscribe_to_start_next_pending_job_execution_rejected(
            request=start_subscription_request,
            qos=mqtt5.QoS.AT_LEAST_ONCE,
            callback=self.on_start_next_pending_job_execution_rejected)

        # Wait for subscriptions to succeed
        subscribed_accepted_future.result()
        subscribed_rejected_future.result()

        logger.info("Subscribing to Update responses...")
        # Note that we subscribe to "+", the MQTT wildcard, to receive
        # responses about any job-ID.
        update_subscription_request = iotjobs.UpdateJobExecutionSubscriptionRequest(
            thing_name=config.client_id,
            job_id='+')

        subscribed_accepted_future, _ = self.jobs_client.subscribe_to_update_job_execution_accepted(
            request=update_subscription_request,
            qos=mqtt5.QoS.AT_LEAST_ONCE,
            callback=self.on_update_job_execution_accepted)

        subscribed_rejected_future, _ = self.jobs_client.subscribe_to_update_job_execution_rejected(
            request=update_subscription_request,
            qos=mqtt5.QoS.AT_LEAST_ONCE,
            callback=MQTT.on_update_job_execution_rejected)

        # Wait for subscriptions to succeed
        subscribed_accepted_future.result()
        subscribed_rejected_future.result()

        self.try_start_next_job()

    def try_start_next_job(self):
        logger.info("Trying to start the next job...")
        with locked_data.lock:
            if locked_data.is_working_on_job:
                logger.info("already working on a job, will try later")
                return

            if locked_data.disconnect_called:
                logger.info("Ignoring, service is disconnecting.")
                return

            locked_data.is_working_on_job = True
            locked_data.is_next_job_waiting = False

        logger.info("Publishing request to start next job...")
        request = iotjobs.StartNextPendingJobExecutionRequest(thing_name=config.client_id)
        publish_future = self.jobs_client.publish_start_next_pending_job_execution(request, mqtt5.QoS.AT_LEAST_ONCE)
        publish_future.add_done_callback(MQTT.on_publish_start_next_pending_job_execution)

    @staticmethod
    def on_publish_start_next_pending_job_execution(future):
        # type: (Future) -> None
        try:
            future.result()  # raises exception if publish failed
            logger.info("Published request to start the next job.")

        except Exception as e:
            logger.error(f"Error publishing request for next_pending_job_execution", e)

    def on_update_job_execution_accepted(self, response):
        # type: (iotjobs.UpdateJobExecutionResponse) -> None
        try:
            logger.info("Request to update job was accepted.")
            self.done_working_on_job()
        except Exception as e:
            logger.error(f"Error in request for update job", e)

    def done_working_on_job(self):
        with locked_data.lock:
            locked_data.is_working_on_job = False
            try_again = locked_data.is_next_job_waiting

        if try_again:
            self.try_start_next_job()

    @staticmethod
    def on_update_job_execution_rejected(rejected):
        # type: (iotjobs.RejectedError) -> None
        logger.error("Request to update job status was rejected. code:'{}' message:'{}'.".format(
            rejected.code, rejected.message))

    def on_start_next_pending_job_execution_accepted(self, response):
        # type: (iotjobs.StartNextJobExecutionResponse) -> None
        try:
            if not response.execution:
                logger.info("Request to start next job was accepted, "
                            "but there are no jobs to be done. Waiting for further jobs...")
                self.done_working_on_job()
                return

            execution = response.execution
            logger.info("Request to start next job was accepted. job_id:{} job_document:{}".format(
                execution.job_id, execution.job_document))

            # To emulate working on a job, spawn a thread that sleeps for a few seconds
            job_thread = threading.Thread(
                target=lambda: self.job_thread_fn(execution.job_id, execution.job_document),
                name='job_thread')
            job_thread.start()

        except Exception as e:
            logger.error(e)

    def job_thread_fn(self, job_id, job_document):
        try:
            logger.info("Starting local work on job...")
            operation = job_document.get('operation', 'update_config')
            if operation == 'update_config':
                self.update_config(job_document)
            elif operation == 'create_custom_test':
                self.create_new_custom_test(job_document)
            elif operation == 'update_custom_test':
                self.update_custom_test(job_document)
            elif operation == 'delete_custom_test':
                self.delete_custom_test(job_document)
            else:
                logger.info('unknown operation!')

            logger.info("Done working on job.")

            logger.info("Publishing request to update job status to SUCCEEDED...")
            request = iotjobs.UpdateJobExecutionRequest(
                thing_name=config.client_id,
                job_id=job_id,
                status=iotjobs.JobStatus.SUCCEEDED)
            publish_future = self.jobs_client.publish_update_job_execution(request, mqtt5.QoS.AT_LEAST_ONCE)
            publish_future.add_done_callback(self.on_publish_update_job_execution)

        except Exception as e:
            logger.error(e)

    def on_publish_update_job_execution(self, future):
        # type: (Future) -> None
        try:
            future.result()  # raises exception if publish failed
            logger.info("Published request to update job.")

        except Exception as e:
            logger.info(f"error: {e}")

    def on_start_next_pending_job_execution_rejected(self, rejected):
        # type: (iotjobs.RejectedError) -> None
        logger.info(f"Request to start next pending job rejected with code:{rejected.code},"
                    f" message: {rejected.message}")

    def on_next_job_execution_changed(self, event):
        # type: (iotjobs.NextJobExecutionChangedEvent) -> None
        try:
            execution = event.execution
            if not execution:
                logger.info("Received Next Job Execution Changed event: None. Waiting for further jobs...")
                return

            logger.info("Received Next Job Execution Changed event. job_id:{} job_document:{}".format(
                execution.job_id, execution.job_document))

            # Start job now, or remember to start it when current job is done
            start_job_now = False
            with locked_data.lock:
                if locked_data.is_working_on_job:
                    locked_data.is_next_job_waiting = True
                else:
                    start_job_now = True

            if start_job_now:
                logger.info("will try to start working on job")
                self.try_start_next_job()

        except Exception as e:
            logger.error("error on next_job_execution_changed", e)

    @staticmethod
    def on_get_pending_job_executions_rejected(error):
        # type: (iotjobs.RejectedError) -> None
        logger.info(f"Request rejected: {error.code}: {error.message}")

    @staticmethod
    def on_get_pending_job_executions_accepted(response):
        # type: (iotjobs.GetPendingJobExecutionsResponse) -> None
        with locked_data.lock:
            if len(response.queued_jobs) > 0 or len(response.in_progress_jobs) > 0:
                for job in response.in_progress_jobs:
                    MQTT.available_jobs.append(job)
                    logger.info(f"In Progress: {job.job_id} @ {job.last_updated_at}")
                for job in response.queued_jobs:
                    MQTT.available_jobs.append(job)
                    logger.info(f"Queued job:  {job.job_id} @ {job.last_updated_at}")
            else:
                logger.info("No pending or queued jobs found!")
            locked_data.got_job_response = True

    @staticmethod
    def on_lifecycle_stopped(lifecycle_stopped_data: mqtt5.LifecycleStoppedData):
        logger.info("Lifecycle Stopped")

    @staticmethod
    def on_lifecycle_connection_success(lifecycle_connect_success_data: mqtt5.LifecycleConnectSuccessData):
        logger.info("Lifecycle Connection Success")
        MQTT.future_connection_success.set_result(lifecycle_connect_success_data)

    @staticmethod
    def on_lifecycle_connection_failure(lifecycle_connection_failure: mqtt5.LifecycleConnectFailureData):
        logger.error("Lifecycle Connection Failure")
        logger.error("Connection failed with exception: {}".format(lifecycle_connection_failure.exception))

    def publish_to_topic(self, topic, payload):
        self.mqtt5_client.publish(
            mqtt5.PublishPacket(
                topic=topic,
                payload=json.dumps(payload) if isinstance(payload, (dict, list)) else payload,
                qos=mqtt5.QoS.AT_LEAST_ONCE
            )
        )

    def publish(self, payload):
        self.publish_to_topic(config.topic, payload)

    def deep_update(self, target, source):
        for key, value in source.items():
            if isinstance(value, dict):
                newval = self.deep_update(target.get(key, {}), value)
                target[key] = newval
            else:
                target[key] = value
        return target

    def update_config(self, payload: dict) -> None:
        try:
            new_config = payload
            if 'newConfig' in new_config:
                new_config = new_config['newConfig']
            elif 'config' in new_config:
                new_config = new_config['config']

            with open(config.config_file_path, 'r') as config_file:
                current_config = json.load(config_file)

            old_config = copy.deepcopy(current_config)
            updated_config = self.deep_update(current_config, new_config)

            # update wifi if needed!
            wifi_updated = self.check_wifi_update(old_config, updated_config)

            # nmcli update here
            if wifi_updated:
                self.update_wifi(updated_config)

            with open(config.config_file_path, 'w') as config_file:
                json.dump(updated_config, config_file, indent=2)
            logger.info("Configuration updated successfully!")
        except Exception as e:
            logger.info(f"Failed to update configuration: {e}")

    def check_wifi_update(self, old_config, updated_config):
        old_wifi_networks = old_config.get('wifiv2', [])
        updated_wifi_networks = updated_config.get('wifiv2', [])

        if len(old_wifi_networks) != len(updated_wifi_networks):
            return True
        
        for i in range(len(old_wifi_networks)):
            old_net = old_wifi_networks[i]
            updated_net = updated_wifi_networks[i]

            if (old_net.get('ssid') != updated_net.get('ssid') or
                old_net.get('psk') != updated_net.get('psk') or
                old_net.get('enterprise') != updated_net.get('enterprise') or
                old_net.get('preference') != updated_net.get('preference')):
                return True
        return False
    
    def configure_non_enterprise_wifi(self, profile_name, wifi_connection):
        nmcli.connection.modify(profile_name, {
            '802-11-wireless.ssid': wifi_connection["ssid"],
            'wifi-sec.key-mgmt': 'wpa-psk',
            'wifi-sec.psk': wifi_connection["psk"],
        })

    def configure_enterprise_wifi(self, profile_name, wifi_connection):
        nmcli.connection.modify(profile_name, {
            '802-11-wireless.ssid': wifi_connection["ssid"],
            'wifi-sec.key-mgmt': 'wpa-eap',
            '802-1x.eap': 'peap',
            '802-1x.phase2-auth': 'mschapv2',
            '802-1x.identity': wifi_connection["username"],
            '802-1x.password': wifi_connection["psk"],
        })

    def update_wifi(self, updated_config):

        wifi_connections = updated_config["wifiv2"]
        profile_mapping = {
            1: ('wifi-profile-1', 'wifi-enterprise-1'),
            2: ('wifi-profile-2', 'wifi-enterprise-2'), 
            3: ('wifi-profile-3', 'wifi-enterprise-3')
        }
        try:
            for wifi_connection in wifi_connections:
                preference = wifi_connection.get("preference")
                non_enterprise_wifi_profile, enterprise_wifi_profile = profile_mapping[preference]
                if wifi_connection.get('enterprise'):
                    nmcli.connection.modify(non_enterprise_wifi_profile, {
                        'connection.autoconnect': 'no'
                        })
                    nmcli.connection.modify(enterprise_wifi_profile, {
                        'connection.autoconnect': 'yes'
                        })
                    self.configure_enterprise_wifi(enterprise_wifi_profile, wifi_connection)
                else:
                    nmcli.connection.modify(non_enterprise_wifi_profile, {
                        'connection.autoconnect': 'yes'
                        })
                    nmcli.connection.modify(enterprise_wifi_profile, {
                        'connection.autoconnect': 'no'
                        })
                    self.configure_non_enterprise_wifi(non_enterprise_wifi_profile, wifi_connection)
            self.lcd_display_logger.log("updated creds! please restart")
        except Exception as e:
            self.lcd_display_logger.log(f'Unable to update creds')


    def create_new_custom_test(self, job_document):
        paylaod = job_document.get("payload", {})
        code = paylaod.get("code", "")
        metadata = paylaod.get("metadata", {})
        test_name = metadata.get("name")

        if not test_name or not code:
            raise ValueError(
                "Missing name in metadata or 'code' in job document")

        custom_tests_dir = "/opt/netmeldr/netprobe/custom_tests"
        test_dir = os.path.join(custom_tests_dir, test_name)

        os.makedirs(custom_tests_dir, exist_ok=True)

        # Remove existing folder if it exists
        if os.path.exists(test_dir):
            shutil.rmtree(test_dir)
            logger.info(f"Deleted existing directory: {test_dir}")

        os.makedirs(test_dir)
        logger.info(f"Created directory: {test_dir}")

        # Write metadata.json
        metadata_path = os.path.join(test_dir, "metadata.json")
        with open(metadata_path, "w") as metadata_file:
            json.dump(metadata, metadata_file, indent=2)
        logger.info(f"Created {metadata_path}")

        # Write main.py
        main_py_path = os.path.join(test_dir, "main.py")
        with open(main_py_path, "w") as main_file:
            main_file.write(code)
        logger.info(f"Created {main_py_path}")

    def update_custom_test(self, job_document):
        paylaod = job_document.get("payload", {})
        code = paylaod.get("code", "")
        metadata = paylaod.get("metadata", {})
        test_name = metadata.get("name")

        if not test_name or not code:
            raise ValueError(
                "Missing test name in job document")

        custom_tests_dir = "/opt/netmeldr/netprobe/custom_tests"
        test_dir = os.path.join(custom_tests_dir, test_name)

        # Delete existing test folder if it exists
        if os.path.exists(test_dir):
            try:
                shutil.rmtree(test_dir)
                logger.info(
                    f"Deleted existing directory for update: {test_dir}")
            except Exception as e:
                logger.error(f"Failed to delete directory {test_dir}: {e}")
                raise

        # Create a new test directory
        try:
            os.makedirs(test_dir)
            logger.info(f"Created directory: {test_dir}")
        except Exception as e:
            logger.error(f"Failed to create directory {test_dir}: {e}")
            raise

        # Write metadata.json
        metadata_path = os.path.join(test_dir, "metadata.json")
        try:
            with open(metadata_path, "w") as metadata_file:
                json.dump(metadata, metadata_file, indent=2)
            logger.info(f"Created metadata file: {metadata_path}")
        except Exception as e:
            logger.error(f"Failed to write metadata file {metadata_path}: {e}")
            raise

        # Write main.py
        main_py_path = os.path.join(test_dir, "main.py")
        try:
            with open(main_py_path, "w") as main_file:
                main_file.write(code)
            logger.info(f"Created main.py file: {main_py_path}")
        except Exception as e:
            logger.error(f"Failed to write main.py file {main_py_path}: {e}")
            raise

    def delete_custom_test(self, job_document):
        paylaod = job_document.get("payload", {})
        code = paylaod.get("code", "")
        metadata = paylaod.get("metadata", {})
        test_name = metadata.get("name")

        if not test_name:
            raise ValueError("Missing 'name' in metadata")

        custom_tests_dir = "/opt/netmeldr/netprobe/custom_tests"
        test_dir = os.path.join(custom_tests_dir, test_name)

        if os.path.exists(test_dir):
            try:
                shutil.rmtree(test_dir)
                logger.info(
                    f"Successfully deleted custom test directory: {test_dir}")
            except Exception as e:
                logger.error(f"Failed to delete directory {test_dir}: {e}")
                raise
        else:
            logger.warning(f"Directory does not exist: {test_dir}")
