"""
Copyright (c) 2024 Netmeldr. All rights reserved.

This file is part of Netprobe IOT device, which is proprietary software.
Unauthorized copying, modification, distribution, or use of this file,
via any medium, is strictly prohibited.
"""
import os
from dataclasses import dataclass


@dataclass
class MQTTConfig:
    client_id: str
    endpoint: str
    mqtt_port: int
    cert_filepath: str
    pri_key_filepath: str
    ca_filepath: str
    topic: str
    config_file_path: str
    log_file_path: str


cert_base_path = os.getenv("CERT_PATH")
client_id = os.getenv("CLIENT_ID")
topic = os.getenv("MQTT_TOPIC")
endpoint = os.getenv("MQTT_ENDPOINT")
log_path = os.getenv("LOG_FILE_PATH", '/opt/netmeldr/logs/')
config_json_file_path = os.getenv("CONFIG_FILE_PATH", '/opt/netmeldr/netprobe/config/config.json')

config = MQTTConfig(client_id=client_id,
                    endpoint=endpoint,
                    mqtt_port=8883,
                    cert_filepath=f"{cert_base_path}/{client_id}.cert.pem",
                    pri_key_filepath=f"{cert_base_path}/{client_id}.private.key",
                    ca_filepath=f"{cert_base_path}/root-CA.crt",
                    topic=topic,
                    config_file_path=config_json_file_path,
                    log_file_path=log_path
                    )
