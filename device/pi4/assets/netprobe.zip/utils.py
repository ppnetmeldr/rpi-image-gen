"""
Copyright (c) 2024 Netmeldr. All rights reserved.

This file is part of Netprobe IOT device, which is proprietary software.
Unauthorized copying, modification, distribution, or use of this file,
via any medium, is strictly prohibited.
"""
import re
import socket
import subprocess

from containers.global_logger import get_file_logger

logger = get_file_logger("Utils", "utils.log")


def run_iw_config():
    try:
        return subprocess.check_output(['iwconfig', 'wlan0']).decode('utf-8')
    except subprocess.CalledProcessError as e:
        logger.error(f"Error executing iwconfig: {e}")
        return None


def run_iw_list():
    try:
        return subprocess.check_output(['iwlist', 'wlan0', 'scan']).decode('utf-8')
    except subprocess.CalledProcessError as e:
        logger.error(f"Error executing iwlist: {e}")
        return None


def get_iw_config():
    cmd_output = run_iw_config()
    if not cmd_output:
        logger.error("No iwconfig details available to parse.")
        return None

    return parse_iw_config(cmd_output)


def parse_iw_config(txt_input: str):
    data = {}
    patterns = {
        "ESSID": r'ESSID:"([^"]+)"',
        "Mode": r"Mode:(\w+)",
        "Frequency": r"Frequency:([\d.]+)\s([A-Za-z]+)",
        "Access Point": r"Access Point: ([0-9A-Fa-f:]+)",
        "Bit Rate": r"Bit Rate=([\d.]+)\s([A-Za-z/]+)",
        "Tx-Power": r"Tx-Power=([\d.]+)\s([A-Za-z]+)",
        "Retry short limit": r"Retry short limit:(\d+)",
        "RTS thr": r"RTS thr:(\w+)",
        "Fragment thr": r"Fragment thr:(\w+)",
        "Power Management": r"Power Management:(\w+)",
        "Link Quality": r"Link Quality=(\d+)/(\d+)",
        "Signal level": r"Signal level=([-\d]+)\s([A-Za-z]+)",
        "Rx invalid nwid": r"Rx invalid nwid:(\d+)",
        "Rx invalid crypt": r"Rx invalid crypt:(\d+)",
        "Rx invalid frag": r"Rx invalid frag:(\d+)",
        "Tx excessive retries": r"Tx excessive retries:(\d+)",
        "Invalid misc": r"Invalid misc:(\d+)",
        "Missed beacon": r"Missed beacon:(\d+)",
    }

    for key, pattern in patterns.items():
        match = re.search(pattern, txt_input)
        if not match:
            continue

        if key == "Link Quality":
            data[key] = f"{match.group(1)}/{match.group(2)}"
        elif len(match.groups()) > 1:
            data[key] = f"{match.group(1)} {match.group(2)}"
        else:
            data[key] = match.group(1)

    return data


def get_ip_address():
    cmd = "hostname -I | cut -d' ' -f1"
    ip = "unassigned"
    try:
        ip = subprocess.check_output(cmd, shell=True).decode('UTF-8').strip()
    except Exception as e:
        logger.error("could not get ip address", e)
    return ip


def get_iw_list():
    result = {
        'CHANNEL': None,
        'FREQUENCY': None,
        "QUALITY": None,
        "SIGNAL_LEVEL": None,
        "BIT_RATES": [],
    }

    wlan_text = run_iw_list()
    lines = wlan_text.split('\n')

    for line in lines:
        line = line.strip()
        if 'Channel:' in line:
            result['CHANNEL'] = line.split('Channel:')[1].split()[0]

        if 'Frequency:' in line:
            result['FREQUENCY'] = line.split('Frequency:')[1].split()[0]

        if 'Quality' in line:
            result["QUALITY"] = line.split('Quality=')[1].split()[0]

        if 'Signal level=' in line:
            result['SIGNAL_LEVEL'] = line.split("Signal level=")[1].split()[0]

        if "Bit Rates:" in line:
            rates = line.split('Bit Rates:')[1].strip()
            bit_rates = [rate.strip() for rate in rates.split(';')]
            # TODO: bitrates is too much!
            # result['BIT_RATES'].extend(bit_rates)

    return result


def run_nmcli():
    text = subprocess.check_output(
        ['nmcli', '-f', 'IN-USE,BSSID,SSID,MODE,CHAN,RATE,SIGNAL,BARS,FREQ', 'device', 'wifi']).decode('utf-8')

    bars_to_percentage = {
        '▂___': '25',
        '▂▄__': '50',
        '▂▄▆_': '75',
        '▂▄▆█': '100'
    }

    # Regular expression pattern to match each line of the table
    pattern = re.compile(
        r'(?P<in_use>\*?)\s+'
        r'(?P<bssid>(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2})\s+'
        r'(?P<ssid>\S+(?:\s+\S+)*?)\s{2,}'
        r'(?P<mode>Infra)\s+'
        r'(?P<chan>\d+)\s+'
        r'(?P<rate>\d+ Mbit/s)\s+'
        r'(?P<signal>\d+)\s+'
        r'(?P<bars>\S+)\s+'
        r'(?P<frequency>[\w\s]+)'
    )

    # Parse each line and store the results in a list of dictionaries
    networks = []
    for match in pattern.finditer(text):
        network = match.groupdict()
        network['in_use'] = bool(network['in_use'])  # Convert in_use to a boolean
        networks.append(network)

    # Output the parsed data
    for network in networks:
        if not network['in_use']:
            continue

        network['quality'] = bars_to_percentage[network['bars']]
        return network


def get_signal_strength():
    out = run_iw_config()
    pattern = r"Signal level=([-\d]+)\s([A-Za-z]+)"
    match = re.search(pattern, out)
    if not match:
        return 0
    return match.group(1)


def get_wifi_info():
    try:
        out = run_nmcli()
        signal = get_signal_strength()
        return {
            'CHANNEL': out.get('chan', None),
            'FREQUENCY': out.get('frequency', None),
            "QUALITY": out.get('quality', None),
            "SIGNAL_LEVEL": signal,
            "BIT_RATES": out.get('rate', None),
            "ACCESS_POINT": out.get('bssid', None),
            "ESSID": out.get('ssid', None)
        }
    except Exception as e:
        logger.error("Could not get data from nmcli", e)
        return None


def is_wifi_connected(interface="wlan0"):
    """Check if the device has any active network connection."""
    try:
        # Check if the interface has an IP address
        result = subprocess.run(
            ["ip", "addr", "show", interface],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        if "inet " in result.stdout:
            return True  # Interface has an IP address
    except FileNotFoundError:
        print(f"Error: Command to check interface {interface} failed.")

    # Check internet connectivity via DNS
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True  # Internet is reachable
    except socket.error:
        return False


if __name__ == '__main__':
    print(run_nmcli())
