"""
Copyright (c) 2024 Netmeldr. All rights reserved.

This file is part of Netprobe IOT device, which is proprietary software.
Unauthorized copying, modification, distribution, or use of this file,
via any medium, is strictly prohibited.
"""
import copy
from typing import Dict

import uvicorn
from fastapi import FastAPI
from fastapi_utils.tasks import repeat_every
from pydantic import BaseModel

from service import LCDService

app = FastAPI()
display_service = LCDService()
iw_events = []


@app.on_event("startup")
@repeat_every(seconds=1)
def display_loop():
    display_service.update_display()


@app.get("/")
def root():
    return {"hello": "world"}


class LogsCreation(BaseModel):
    logs: str


@app.post("/logs")
async def add_logs(logs: LogsCreation):
    display_service.log(logs.logs)
    return {"status": "OK"}


@app.post("/iwevent")
async def add_iw_events(payload: Dict):
    iw_events.append(payload)
    return {"status": "Accepted"}


@app.get("/iwevent")
async def get_iw_events():
    result = copy.deepcopy(iw_events)
    iw_events.clear()
    return result


@app.get("/iwdata")
async def get_iwdata():
    return display_service.get_iw_data()


if __name__ == '__main__':
    uvicorn.run(app, host='0.0.0.0', port=8888)
