"""
Copyright (c) 2024 Netmeldr. All rights reserved.

This file is part of Netprobe IOT device, which is proprietary software.
Unauthorized copying, modification, distribution, or use of this file,
via any medium, is strictly prohibited.
"""
import json
import re
import subprocess
import threading
import time

from ina219 import INA219

from config.config import config
from containers.global_logger import get_file_logger
from display_img_service import DisplayImageService
from libraries.LCDLib import LCDLib
from utils import get_ip_address, is_wifi_connected, get_wifi_info

CONFIG_PATH = config.config_file_path

logger = get_file_logger('DisplayService', 'display-service.log')


class BatterySensor:
    SHUNT_OHMS = 0.1

    def __init__(self):
        try:
            self.ina = INA219(BatterySensor.SHUNT_OHMS, busnum=1)
            self.ina.configure()
        except Exception as e:
            logger.error('Could not initialize I2C bat sensor.', e)
            self.ina = None

    @property
    def battery_voltage(self):
        if not self.ina:
            return 9
        try:
            return self.ina.voltage()
        except Exception as e:
            logger.error('Could not read voltage from bat sensor', e)
            return 9

    @property
    def battery_current(self):
        if not self.ina:
            return 0
        try:
            return self.ina.current()
        except Exception as e:
            logger.error('Could not read current from bat sensor', e)
            return 0

    def percentage(self):
        low_volt = 9
        max_volt = 12.1
        return int((self.battery_voltage - low_volt) / (max_volt - low_volt) * 100)


class LCDService:
    def __init__(self):
        super().__init__()

        self.lcd = LCDLib()
        self.lcd.Init()
        self.lcd.clear()
        self.lcd.bl_DutyCycle(100)

        self.display_image_service = DisplayImageService()
        self._refresh_display()

        self.battery_sensor = BatterySensor()

        self._wifi_check_thread = None
        self.wifi_connected = False
        self.link_quality = None
        self.wifi_signal_strength = None
        self.ssid = None
        self.device_name = LCDService._read_device_name()
        self.logs = []

        # TODO: refactor this into different class
        self.iw_buffer = []
        self.iw_events_buffer = []
        self.max_data_points = 300
        self.max_event_buffer_data_points = 20

    def get_iw_data(self):
        result = self.iw_buffer
        self.iw_buffer = []
        return result

    def update_iw(self):
        data = get_wifi_info()

        if not data:
            return None

        self.iw_buffer.append({'time': time.time(), 'data': data})
        if len(self.iw_buffer) > self.max_data_points:
            self.iw_buffer = []

        return data

    def update_display(self):
        self._update_non_wifi_data()

        # Start the Wi-Fi connectivity check in the background
        if not self._wifi_check_thread or not self._wifi_check_thread.is_alive():
            self._wifi_check_thread = threading.Thread(target=self._check_wifi_connection_in_background)
            self._wifi_check_thread.daemon = True
            self._wifi_check_thread.start()

        self._refresh_display()

    def _update_non_wifi_data(self):
        self._update_device_name()
        self._update_battery()
        self._update_cpu_temp()
        self._update_ip_address()

    def _update_device_name(self):
        self.display_image_service.draw_device_name(self.device_name)

    def _update_battery(self):
        percentage = self.battery_sensor.percentage()
        self.display_image_service.draw_battery(percentage)

    def _update_cpu_temp(self):
        cpu_temp = self._get_cpu_temperature()
        self.display_image_service.draw_cpu_temperature(cpu_temp)

    def _update_ip_address(self):
        self.display_image_service.draw_ip_address(get_ip_address())

    def _check_wifi_connection_in_background(self):
        """
        Performing Wi-Fi connection check in the background for up to 90 seconds.
        Updates the Wi-Fi connection status and screen when connectivity is established.
        """
        retry_duration = 90
        retry_interval = 5
        start_time = time.time()

        while time.time() - start_time < retry_duration:
            if is_wifi_connected():
                self.wifi_connected = True
                self._update_wifi_data()
                self._refresh_display()
                return
            time.sleep(retry_interval)

        # No internet connection after retries
        self.wifi_connected = False
        self.lcd.clear()
        self._display_error('WiFi not connected! Reboot!!')
        self._refresh_display()

    def _update_wifi_data(self):
        iw_dict = self.update_iw()

        if not iw_dict:
            return

        self._update_ssid(iw_dict)
        self._update_wifi_strength(iw_dict)
        self._update_link_quality(iw_dict)

    def _refresh_display(self):
        self.lcd.ShowImage(self.display_image_service.get_image())

    def _display_error(self, error_msg):
        self.display_image_service.draw_system_message(error_msg)

    def _clear_error(self):
        self.display_image_service.draw_system_message(None)

    def _update_link_quality(self, iw_config):
        link_quality = iw_config.get("QUALITY", "0/0").split('/')
        link_quality_upper = int(link_quality[0])
        if self.link_quality == link_quality_upper:
            return
        self.link_quality = link_quality_upper
        self.display_image_service.draw_link_quality(link_quality_upper)

    def _update_wifi_strength(self, iw_config):
        wifi_signal_strength = iw_config.get("SIGNAL_LEVEL", None)
        if self.wifi_signal_strength == wifi_signal_strength:
            return
        self.wifi_signal_strength = wifi_signal_strength
        self.display_image_service.draw_signal_strength(wifi_signal_strength)

    def _update_ssid(self, iw_config):
        device_ssid = iw_config.get("ESSID", None)
        if self.ssid == device_ssid:
            return

        self.display_image_service.draw_wifi(device_ssid)
        self.ssid = device_ssid

    @staticmethod
    def _get_cpu_temperature():
        output = subprocess.check_output(["vcgencmd", "measure_temp"]).decode('utf-8')
        match = re.search(r'temp=([\d.]+)', output)
        return 0 if not match else float(match.group(1))

    @staticmethod
    def _read_device_name():
        try:
            with open(CONFIG_PATH, 'r') as f:
                cfg = json.load(f)
                return cfg.get("device_name", "Default Device ")
        except FileNotFoundError:
            logger.info(f"Configuration file not found at {CONFIG_PATH}. Using default device name.")
            return "Default Device Name"
        except json.JSONDecodeError as e:
            logger(f"Error decoding JSON from {CONFIG_PATH}: {e}")
            return "Netprobe"

    def log(self, statement):
        self.logs.append(statement)
        if len(self.logs) > 8:
            self.logs.pop(0)
        self.display_image_service.draw_logs(self.logs)
        # logs would soon appear anyway! TODO: Test this!!
        # self._refresh_display()
