"""
Copyright (c) 2025 Netmeldr. All rights reserved.

This file is part of Netprobe IOT device, which is proprietary software.
Unauthorized copying, modification, distribution, or use of this file,
via any medium, is strictly prohibited.
"""
import tkinter as tk

from PIL import ImageTk

from display_img_service import DisplayImageService

"""
Handy tool for developing the LCD graphics for netprobe.
"""


def display_image(img):
    # Create a Tkinter window
    root = tk.Tk()
    root.title("Image Viewer")

    # Convert PIL Image to Tkinter PhotoImage
    tk_img = ImageTk.PhotoImage(img)

    # Create a label and pack it into the window
    label = tk.Label(root, image=tk_img)
    label.pack()

    # Keep a reference to the image to prevent garbage collection
    label.image = tk_img

    # Start the Tkinter event loop
    root.mainloop()


# Example usage
if __name__ == "__main__":
    # Replace with your image path
    display_service = DisplayImageService()
    display_service.debug = False
    display_service.draw_wifi("Airtel_random")
    display_service.draw_battery(125)
    display_service.draw_device_name("netprobe-new-24")
    display_service.draw_link_quality(90)
    display_service.draw_signal_strength(24)

    logs = ['hello', 'hello from netmeldr', 'how many lines??', 'hello',
            'hello from netmeldr', 'how many lines??', 'one more', 'two more']
    display_service.draw_logs(logs)

    display_service.draw_system_message('there is an error!')

    display_service.draw_ip_address('111.222.333.444')
    display_service.draw_cpu_temperature(25)

    # show the image
    display_image(display_service.get_image(0))
